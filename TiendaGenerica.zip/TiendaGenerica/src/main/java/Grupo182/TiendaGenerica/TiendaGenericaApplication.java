package Grupo182.TiendaGenerica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaGenericaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaGenericaApplication.class, args);
	}

}
