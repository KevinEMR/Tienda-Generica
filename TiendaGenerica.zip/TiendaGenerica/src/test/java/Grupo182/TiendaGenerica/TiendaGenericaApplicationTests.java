package Grupo182.TiendaGenerica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaGenericaApplicationTests {

	@Test
	void contextLoads() {
	}

}
